# Dọn artifact trước C2 — hoàn tất

Thời điểm đối chiếu cuối: 2026-11-14T05:31:51.320144+00:00. Chỉ xóa các mục đã duyệt dưới `D:\Data\AnimeMMORPG\Artifacts`; không khởi chạy game/build/test, không đóng/save/restart hoặc điều khiển Editor. Chưa triển khai C2.

## Dung lượng thực đo

|Nhóm|Ứng viên GiB|Đã xóa, byte logic GiB|
|---|---:|---:|
|Intermediate trong clone|85.029|84.938|
|Archive cũ|44.363|44.336|
|Binaries clone U00–B1|12.226|12.226|
|Saved/Cooked, StagedBuilds, Shaders|23.957|21.006|
|Tổng|165.574|162.505|

- Đã xóa **3,310 mục** bằng PowerShell `Remove-Item -LiteralPath`, không force, không git clean/reset và không giải phóng khóa bằng đóng process. Nhật ký: **{'DELETED': 3310}**; không còn target nào trong danh sách xóa.
- Dung lượng trống ổ D tăng **162.515 GiB**, từ 56.503 lên **219.018 GiB**. Đây là chênh lệch free-space đo trên volume khi Editor vẫn mở; có thể lệch nhẹ với byte logic do allocation/metadata và hoạt động nền.
- Dự án còn khoảng **51.006 GiB** byte logic, gồm audit tại thời điểm ghi báo cáo; Artifacts còn 40.529 GiB. Vì giữ thêm khoảng **3.069 GiB** metadata/manifest và file có định dạng bằng chứng, kết quả không xuống khoảng48 GiB dự kiến nếu toàn bộ ứng viên đều được xóa.

## Giữ nguyên và xác minh

- **122,635 file** được bảo vệ đã đối chiếu SHA-256 trước/sau, không thiếu hoặc đổi nội dung. Bao gồm mọi file không xóa trong Artifacts (clone source/Git, log/trace/video/manifest/failed-invalid/crash data, B2/C1 binaries/packages) và dữ liệu tĩnh repo chính Source/Content/Config/Plugins/Docs/Scripts/Git có trước lượt dọn. File mới của công cụ/audit được ghi riêng.
- Repo chính Saved/autosave/Binaries/Intermediate/.vs chưa từng là target; mọi thao tác xóa đều bị chặn ngoài Artifacts. Editor gốc vẫn mở; log/transient của chính Editor có thể tự thay đổi trong thời gian chạy, không được giả định bất biến byte. Không có lệnh Editor/Live Coding hoặc dừng process nào được gọi.
- Git HEAD giữ nguyên `8d1d2c37bc6259a58dd110a63f4fc1d3963b058f`. Private `Config/DefaultEngine.ini` giữ hash `412b42b66583f9b6e4ecdc63cd2423457bf0b1a3d192f5b0f18375ee801f8161` và thay đổi cục bộ có sẵn vẫn ngoài staging. Không commit/push hoặc thay đổi ref Git trong lượt dọn.
- SHA của **19 clone** giữ nguyên. Không xóa cả clone Source, Saved hoặc Artifacts; không sửa launcher hoặc manifest lịch sử.

|Launcher|Source SHA giữ lại|Kiểm tra sau dọn|
|---|---|---|
|B2 solo/network|`515f8190a35afbc8663669419c6ce502967e3df3`|2 binary, 48 package file, engine hash và clone/config PASS|
|C1 solo/network|`dbe10dab1cd6a9b14c28c732aba66f21d525ac69`|2 binary, 48 package file, engine hash và clone/config PASS|

Hai package giữ nguyên toàn bộ:

- `Artifacts/U03/B2/Runs/Package-20261113-121631/Archive/Windows`
- `Artifacts/U03/C1/Runs/Package-20261113-181403/Archive/Windows`

Các dependency/hash check tĩnh của B2/C1 đạt, **không khởi chạy launcher để smoke runtime** theo yêu cầu. Editor network có thể cần làm ấm lại cache sinh tự động ở lần mở sau. Launcher U00–B1 có thể không chạy cho tới khi dựng lại binary/package đã loại bỏ; hồ sơ nghiệm thu và raw evidence vẫn nguyên trạng. Trạng thái READY/ACCEPTED trong manifest lịch sử không bị sửa để che việc dọn binary cũ.

## An toàn và biên bản

Không thấy junction/symlink trong lần inventory Artifacts. Trước mỗi nhóm đều quét lại CWD/command references/disk file handles; không thấy process dùng các target. Probe đọc độc quyền từng file/thư mục và kiểm tra lại reparse point được thực hiện trước Remove-Item. Một số PID hệ thống không cho đọc memory/handle; danh sách được giữ trong process inventory, không nâng quyền hoặc đóng process; probe/Remove-Item không-force giữ lỗi/khóa thay vì vượt qua. Editor gốc đọc được trong kiểm tra process.

Đã đối chiếu **1,084 rawPath** từ manifest lịch sử. Manifest/raw/media/crash/diagnostic files trong vùng ứng viên được giữ thận trọng, kể cả metadata có thể tái sinh. 34 Archive cũ không khai báo SHA sản xuất trong metadata: biên bản ghi rõ SHA clone liên quan ở thời điểm dọn, `producingSourceSHA=null`, không đoán producer hoặc sửa hồ sơ cũ.

- [Danh sách xóa cụ thể, loại/source SHA/byte](DELETE-PLAN.csv), [plan JSON](DELETE-PLAN.json), [plan hash](DELETE-PLAN.sha256).
- [Các mục giữ lại](EXCLUSIONS.json), [đối chiếu manifest](MANIFEST-CROSSCHECK.json), [nhật ký từng thao tác](DELETE-JOURNAL.jsonl), [tổng hợp nhóm](DELETION-SUMMARY.json).
- [Baseline](BEFORE.json), [catalog hash bảo vệ](PROTECTED-BEFORE.jsonl), [kết quả sau dọn](AFTER.json), [log xác minh](VERIFY.log). Process inventories và APPROVED từng nhóm ở cùng thư mục.

Dừng sau dọn; chưa C2. Không chạy lại các script xóa với audit này: journal đã tồn tại và công cụ từ chối replay mù.
